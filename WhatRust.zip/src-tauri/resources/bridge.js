(function () {
  "use strict";
  if (window.location.origin !== "https://web.whatsapp.com") return;
  // Interface language, injected by Rust and re-set live on a language change.
  function L(pt, en) { return window.__WR_LANG === "en" ? en : pt; }

  // 0a) Scrollbars (WebView2 / WebKitGTK only). WhatsApp Web's chat list and
  //     conversation panes have no scrollbar styling of their own, so the
  //     native webviews fall back to their unstyled system scrollbar: a
  //     thick, opaque white/light bar. On Chromium (WebView2) and WebKitGTK
  //     the `::-webkit-scrollbar` rules below DO take effect, so restyle
  //     every scrollbar to a thin, translucent pill instead: WhatsApp's own
  //     muted grey (#8696a0) at low alpha on a transparent track, so it reads
  //     the same in light and dark themes and looks overlay-like. The `*`
  //     selector covers the chat list (#side/#pane-side), the conversation
  //     (#main) and any dialog without betting on WhatsApp's internal class
  //     names, which change between releases. `!important` is scoped to the
  //     scrollbar properties only, so WhatsApp's layout and colours are
  //     untouched — this only replaces the webview's default scrollbar
  //     painting. The 2px transparent border + padding-box clip makes the
  //     visible thumb ~4px wide inside the 8px scrollbar gutter.
  //     macOS is deliberately excluded: WKWebView's page scrollers are
  //     native AppKit NSScrollers that ignore web CSS entirely, so styling
  //     them from here does nothing — Rust forces overlay scrollers
  //     process-wide instead (src/scrollbars.rs). Skipping the stylesheet
  //     there also avoids any chance of web styling forcing legacy scrollbars
  //     back. A Chrome UA is how Linux/Windows present themselves; the
  //     Safari UA on macOS carries no Chrome token.
  try {
    var chromeUA = /Chrome\//.test(navigator.userAgent || "");
    var SCROLLBAR_CSS = [
      "*{scrollbar-width:thin!important;scrollbar-color:rgba(134,150,160,.45) transparent!important}",
      "*::-webkit-scrollbar{width:8px!important;height:8px!important}",
      "*::-webkit-scrollbar-track{background:transparent!important}",
      "*::-webkit-scrollbar-thumb{background-color:rgba(134,150,160,.45)!important;border:2px solid transparent!important;border-radius:4px!important;background-clip:padding-box!important}",
      "*::-webkit-scrollbar-thumb:hover{background-color:rgba(134,150,160,.8)!important}",
      "*::-webkit-scrollbar-corner{background:transparent!important}",
    ].join("");
    var installScrollbars = function () {
      try {
        var head = document.head;
        if (!head) return false;
        if (document.getElementById("__whatrust_scrollbars")) return true;
        var style = document.createElement("style");
        style.id = "__whatrust_scrollbars";
        style.textContent = SCROLLBAR_CSS;
        head.appendChild(style);
        return true;
      } catch (e) {
        return false;
      }
    };
    // An initialization script runs before <head> exists, so in practice
    // this lands on DOMContentLoaded; if <head> is already there, go now.
    if (chromeUA && !installScrollbars() && typeof document.addEventListener === "function") {
      document.addEventListener("DOMContentLoaded", installScrollbars, { once: true });
    }
  } catch (e) {}

  // A rejected command used to vanish here without a trace, which is how every
  // notify/set_unread call being refused by the IPC permission check went
  // unnoticed (issues #3, #32). Warn once per command in the page console
  // (WHATRUST_DEVTOOLS=1 to inspect); the promise still never rejects.
  var warnedCmds = Object.create(null);
  function invoke(cmd, args) {
    var t = window.__TAURI__;
    if (t && t.core && typeof t.core.invoke === "function") {
      return t.core.invoke(cmd, args).catch(function (e) {
        if (warnedCmds[cmd]) return;
        warnedCmds[cmd] = true;
        try { console.warn("[whatRust] " + cmd + " was refused"); } catch (e2) {}
      });
    }
    return Promise.resolve();
  }

  // Zoom shortcuts: Ctrl (Cmd on macOS) with + / - / 0, and Ctrl+wheel. The page
  // only names the action; Rust steps the saved zoom and applies it to every
  // account (zoom_step). Native webview zoom is switched off in window.rs, so
  // there is no second zoom to fight with. Only exact modifier combos are taken
  // (never Alt/AltGr, never mid-composition), everything else reaches WhatsApp.
  var IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || "");
  function zoomKeyAction(e) {
    if (e.isComposing || e.keyCode === 229 || e.altKey) return null;
    if (!(IS_MAC ? e.metaKey && !e.ctrlKey : e.ctrlKey && !e.metaKey)) return null;
    var k = e.key, c = e.code;
    if (k === "+" || k === "=" || c === "NumpadAdd") return "in";
    if (!e.shiftKey && (k === "-" || c === "NumpadSubtract")) return "out";
    if (!e.shiftKey && (k === "0" || c === "Numpad0")) return "reset";
    return null;
  }
  window.addEventListener("keydown", function (e) {
    if (e.defaultPrevented) return;
    var action = zoomKeyAction(e);
    if (!action) return;
    e.preventDefault();
    e.stopPropagation();
    invoke("zoom_step", { action: action });
  }, true);
  // Ctrl+1..9 (Cmd on macOS) opens the Nth account, like browser tabs. Only
  // with more than one account; otherwise the keys reach WhatsApp untouched.
  function accountKeyIndex(e) {
    if (e.isComposing || e.keyCode === 229 || e.altKey || e.shiftKey) return -1;
    if (!(IS_MAC ? e.metaKey && !e.ctrlKey : e.ctrlKey && !e.metaKey)) return -1;
    var m = /^(?:Digit|Numpad)([1-9])$/.exec(e.code || "");
    return m ? Number(m[1]) - 1 : -1;
  }
  window.addEventListener("keydown", function (e) {
    if (e.defaultPrevented) return;
    var i = accountKeyIndex(e);
    if (i < 0) return;
    invoke("switcher_accounts").then(function (list) {
      if (Array.isArray(list) && list.length > 1 && list[i]) invoke("switch_account", { id: list[i].id });
    });
  }, true);
  // A wheel notch, or a trackpad pinch (a burst of ctrl+wheel events), moves one
  // level: deltas accumulate to a threshold, then a short cooldown swallows the
  // rest of the burst.
  var wheelAcc = 0, wheelBusy = false;
  window.addEventListener("wheel", function (e) {
    if (!(IS_MAC ? e.metaKey && !e.ctrlKey : e.ctrlKey && !e.metaKey) || e.altKey) return;
    e.preventDefault();
    if (wheelBusy) return;
    wheelAcc += e.deltaY * (e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? 400 : 1);
    if (Math.abs(wheelAcc) < 40) return;
    var action = wheelAcc < 0 ? "in" : "out";
    wheelAcc = 0;
    wheelBusy = true;
    setTimeout(function () { wheelBusy = false; wheelAcc = 0; }, 150);
    invoke("zoom_step", { action: action });
  }, { capture: true, passive: false });

  // A small, keyboard-accessible account switcher owned by whatRust. It exposes
  // only account names/unread counts and a request to focus an existing account.
  function mountAccountSwitcher() {
    if (window.__WHATRUST_WINDOWS__ || window.__WHATRUST_SINGLE__) return;
    if (!document.body || document.getElementById("__whatrust_accounts")) return;
    // Join the WhatsApp header's normal layout, so the control never covers
    // the navigation icons or conversations. Wait until the header is mounted.
    var header = document.querySelector("#side header, #app header");
    if (!header) return;
    var trigger = document.createElement("button");
    trigger.id = "__whatrust_accounts";
    trigger.type = "button";
    trigger.textContent = "⇄";
    trigger.title = L("Trocar conta do WhatsApp", "Switch WhatsApp account");
    trigger.setAttribute("aria-label", L("Trocar conta do WhatsApp", "Switch WhatsApp account"));
    trigger.setAttribute("aria-haspopup", "dialog");
    trigger.setAttribute("aria-expanded", "false");
    trigger.style.cssText = "position:static;display:inline-flex;align-items:center;justify-content:center;flex:0 0 36px;align-self:center;width:36px;height:36px;margin-inline-start:8px;padding:0;border:1px solid #00806966;border-radius:50%;background:#00806922;color:inherit;font:600 24px system-ui;line-height:1;cursor:pointer;outline-offset:3px";
    var oldDialog = document.getElementById("__whatrust_accounts_dialog");
    if (oldDialog) oldDialog.remove();
    var dialog = document.createElement("dialog");
    dialog.id = "__whatrust_accounts_dialog";
    dialog.setAttribute("aria-label", L("Contas do WhatsApp", "WhatsApp accounts"));
    dialog.style.cssText = "border:0;border-radius:14px;padding:16px;min-width:260px;max-width:90vw;box-shadow:0 8px 36px #0006;font:14px system-ui;color:#222";
    var heading = document.createElement("h2"); heading.textContent = L("Contas do WhatsApp", "WhatsApp accounts");
    heading.style.cssText = "font-size:16px;margin:0 0 10px";
    var list = document.createElement("div"); list.setAttribute("role", "list");
    var close = document.createElement("button"); close.type = "button"; close.textContent = L("Fechar", "Close");
    close.style.cssText = "margin-top:12px;padding:7px 12px;border:0;border-radius:8px;cursor:pointer";
    close.addEventListener("click", function () { dialog.close(); trigger.focus(); });
    dialog.append(heading, list, close);
    dialog.addEventListener("click", function (e) { if (e.target === dialog) { dialog.close(); trigger.focus(); } });
    dialog.addEventListener("close", function () {
      trigger.setAttribute("aria-expanded", "false");
      trigger.focus();
    });
    trigger.addEventListener("click", function (event) {
      event.stopPropagation();
      invoke("switcher_accounts").then(function (accounts) {
        if (!Array.isArray(accounts)) return;
        list.textContent = "";
        accounts.forEach(function (account) {
          var item = document.createElement("button"); item.type = "button";
          var row = document.createElement("div");
          row.setAttribute("role", "listitem");
          item.textContent = String(account.name || "WhatsApp") + (account.unread > 0 ? "  ·  " + account.unread + L(" não lidas", " unread") : "");
          item.setAttribute("aria-label", String(account.name || "WhatsApp") + (account.unread > 0 ? ", " + account.unread + L(" não lidas", " unread") : ""));
          item.style.cssText = "display:block;width:100%;text-align:left;padding:10px;border:0;border-radius:8px;background:white;color:#222;cursor:pointer";
          item.addEventListener("click", function () { invoke("switch_account", { id: account.id }); dialog.close(); });
          row.appendChild(item);
          list.appendChild(row);
        });
        if (!dialog.open) dialog.showModal();
        trigger.setAttribute("aria-expanded", "true");
        var first = list.querySelector("button"); if (first) first.focus(); else close.focus();
      });
    });
    header.appendChild(trigger);
    document.body.appendChild(dialog);
  }
  // React can replace the header when navigating or reconnecting.
  var switcherObserver = new MutationObserver(mountAccountSwitcher);
  function watchAccountSwitcher() {
    if (!document.body) return;
    switcherObserver.observe(document.body, { childList: true, subtree: true });
    mountAccountSwitcher();
  }
  if (document.body) watchAccountSwitcher();
  else document.addEventListener("DOMContentLoaded", watchAccountSwitcher, { once: true });
  var switcherTimer = setInterval(mountAccountSwitcher, 500);
  setTimeout(function () { clearInterval(switcherTimer); }, 30000);

  // Native OS toast with short-window de-duplication. WhatsApp can raise the same alert
  // more than once in a burst (a React re-render, or one message surfacing through two
  // notification code paths), and unlike a browser (which collapses repeats by tag) a
  // native toast stacks every call as a separate visible popup. Suppress an identical
  // title+body seen within DEDUP_MS; genuinely different messages are never affected.
  // Returns true if forwarded, false if suppressed as a duplicate.
  var DEDUP_MS = 3500;
  var recentNotif = Object.create(null);
  // Which notification path the page used, logged once per path (issue #3:
  // on Windows real-message notifications never reached the shim). Names only,
  // never content.
  var seenPath = Object.create(null);
  function notePath(path) {
    if (seenPath[path]) return;
    seenPath[path] = true;
    invoke("dlog", { msg: "notif path: " + path });
  }
  // The sender's picture, from the notification's `icon` (a blob:, data: or
  // https: URL). Loaded, cropped to a square, scaled to ICON_PX and re-encoded
  // as PNG, so Rust gets one small format every toast can show (Windows toasts
  // can't show WebP). Resolves to base64 PNG, or null if it can't be had within
  // ICON_WAIT_MS; the toast then goes out without it. The outcome is logged
  // once per URL scheme, never the picture or its URL.
  var ICON_PX = 96;
  var ICON_WAIT_MS = 1500;
  function iconPng(url) {
    var load = Promise.resolve().then(function () {
      if (typeof window.fetch !== "function" || typeof window.createImageBitmap !== "function") return null;
      return window.fetch(url, { credentials: "omit" })
        .then(function (r) { return r && r.ok ? r.blob() : null; })
        .then(function (blob) { return blob ? window.createImageBitmap(blob) : null; })
        .then(function (bmp) {
          if (!bmp || !bmp.width || !bmp.height) return null;
          var canvas = document.createElement("canvas");
          canvas.width = ICON_PX;
          canvas.height = ICON_PX;
          var side = Math.min(bmp.width, bmp.height);
          canvas.getContext("2d").drawImage(
            bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, 0, 0, ICON_PX, ICON_PX
          );
          if (typeof bmp.close === "function") bmp.close();
          var data = String(canvas.toDataURL("image/png"));
          var at = data.indexOf("base64,");
          return data.indexOf("data:image/png") === 0 && at > 0 ? data.slice(at + 7) : null;
        });
    }).catch(function () { return null; });
    var timeout = new Promise(function (resolve) {
      setTimeout(function () { resolve(null); }, ICON_WAIT_MS);
    });
    return Promise.race([load, timeout]);
  }
  // Windows native path: WebView2 raises the toast from the real Notification
  // and can only read a data: icon itself. For blob:/https: icons, convert the
  // picture here and hand it to Rust, which holds the toast (up to ~1.6 s) and
  // pairs it by title and body. `icon: null` tells Rust there is none to wait for.
  function nativeIcon(title, options) {
    try {
      var icon = options && options.icon;
      var scheme = typeof icon === "string" && (/^(blob|https):/.exec(icon) || [])[1];
      if (!scheme) return;
      var t = String(title || ""), b = String((options && options.body) || "");
      iconPng(icon).then(function (png) {
        notePath("native icon " + scheme + (png ? " ok" : " unavailable"));
        invoke("notification_icon", { title: t, body: b, icon: png || null });
      }, function () {});
    } catch (e) {}
  }
  function nativeNotify(title, body, icon) {
    if(window.__whatrustLocked)return false;
    var epoch=window.__whatrustNotificationEpoch||0;
    function deliver(args){if(window.__WHATRUST_WINDOWS__)args.epoch=epoch;invoke("notify",args);}
    title = String(title || "WhatsApp");
    body = String(body || "");
    var now = Date.now();
    for (var k in recentNotif) {
      if (now - recentNotif[k] > DEDUP_MS) delete recentNotif[k]; // prune stale keys
    }
    var key = title + " " + body;
    if (!window.__WHATRUST_WINDOWS__ && recentNotif[key] && now - recentNotif[key] <= DEDUP_MS) return false;
    recentNotif[key] = now;
    var scheme = typeof icon === "string" && (/^(blob|data|https):/.exec(icon) || [])[1];
    if (!scheme) {
      deliver({ title: title, body: body });
      return true;
    }
    iconPng(icon).then(function (png) {
      notePath("icon " + scheme + (png ? " ok" : " unavailable"));
      deliver(png ? { title: title, body: body, icon: png } : { title: title, body: body });
    });
    return true;
  }

  // 0) Page-error tap -> diagnostic log. WhatsApp failures (e.g. a media worker
  //    dying) are invisible at the process level; forward the page's error
  //    surface to dlog so a hang can be diagnosed from the log alone. Capped and
  //    truncated; technical error text only.
  try {
    var errCount = 0;
    var elog = function (m) {
      if (errCount >= 40) return;
      errCount++;
      try { invoke("dlog", { msg: ("pageerr: " + m).slice(0, 300) }); } catch (e) {}
    };
    window.addEventListener("error", function (e) {
      if (e && e.message) elog("onerror: " + e.message + " @" + (e.filename || "") + ":" + (e.lineno || 0));
    }, true);
    window.addEventListener("unhandledrejection", function (e) {
      var r = e && e.reason;
      elog("unhandledrejection: " + ((r && (r.stack || r.message)) || r));
    });
    // NOTE: we deliberately do NOT hook console.error — WhatsApp routes routine,
    // message-adjacent logs through it, which would risk leaking chat content into
    // the diagnostic log (dlog's no-PII rule). window.onerror / unhandledrejection /
    // worker-onerror capture genuine faults without that exposure.
    // Unhandled errors inside dedicated workers (WhatsApp's wasm media pipeline
    // runs there) never reach window.onerror; wrap the constructor to listen.
    var NativeWorker = window.Worker;
    if (typeof NativeWorker === "function") {
      var WrappedWorker = function Worker(url, opts) {
        var w = opts !== undefined ? new NativeWorker(url, opts) : new NativeWorker(url);
        try {
          w.addEventListener("error", function (e) {
            elog("worker onerror: " + ((e && e.message) || "?") + " @" + ((e && e.filename) || "") + ":" + ((e && e.lineno) || 0));
          });
        } catch (e) {}
        return w;
      };
      WrappedWorker.prototype = NativeWorker.prototype;
      window.Worker = WrappedWorker;
    }
  } catch (e) {}

  // 1) Client Hints shim — navigator.userAgentData is undefined in WebKit
  //    (WebKitGTK on Linux, WKWebView on macOS), which WhatsApp's capability
  //    check can trip over. On Windows WebView2 is Chromium: userAgentData is
  //    real and this shim is skipped. The platform token is derived from the
  //    UA string Rust set (per-OS CHROME_UA), so hints and UA agree instead of
  //    hardcoding "Linux" everywhere.
  var isChromeUA = /Chrome\//.test(navigator.userAgent || "");
  try {
    var uaPlatform = /Macintosh|Mac OS X/.test(navigator.userAgent || "")
      ? "macOS"
      : /Windows/.test(navigator.userAgent || "")
        ? "Windows"
        : "Linux";
    var uaPlatformVersion = uaPlatform === "macOS" ? "13.0.0" : uaPlatform === "Windows" ? "10.0.0" : "6.0.0";
    // Only a Chrome UA gets Chrome's client hints. On macOS the window presents
    // itself as Safari (window.rs `user_agent`, issue #15), and Safari has no
    // userAgentData — adding one would make the fingerprint contradict itself.
    if (!navigator.userAgentData && isChromeUA) {
      Object.defineProperty(navigator, "userAgentData", {
        configurable: true,
        value: {
          brands: [
            { brand: "Chromium", version: "143" },
            { brand: "Google Chrome", version: "143" },
            { brand: "Not_A Brand", version: "24" },
          ],
          mobile: false,
          platform: uaPlatform,
          // Real Chrome returns the requested hints (and these fields are what WhatsApp's
          // capability/calling check reads). The previous shim omitted bitness,
          // fullVersionList and wow64 and left platformVersion empty, which a strict check
          // can treat as "not Chrome". Return the full, internally-consistent set; returning
          // hints that weren't asked for is harmless.
          getHighEntropyValues: function () {
            return Promise.resolve({
              architecture: "x86",
              bitness: "64",
              brands: [
                { brand: "Chromium", version: "143" },
                { brand: "Google Chrome", version: "143" },
                { brand: "Not_A Brand", version: "24" },
              ],
              fullVersionList: [
                { brand: "Chromium", version: "143.0.0.0" },
                { brand: "Google Chrome", version: "143.0.0.0" },
                { brand: "Not_A Brand", version: "24.0.0.0" },
              ],
              mobile: false,
              model: "",
              platform: uaPlatform,
              platformVersion: uaPlatformVersion,
              uaFullVersion: "143.0.0.0",
              wow64: false,
            });
          },
        },
      });
    }
  } catch (e) {}

  // 1b) Chrome environment marker. WhatsApp Web's eligibility checks probe for
  //     `window.chrome` beyond the UA and userAgentData (both spoofed above). Add a
  //     minimal, idempotent stand-in matching what a real Chrome minimally exposes;
  //     never clobber a genuine `window.chrome` (WebView2 on Windows has a real one),
  //     and never add one when the UA is Safari (macOS).
  //     NOTE: this makes the *presentation* consistent; it cannot conjure missing
  //     engine APIs. Linux distro WebKitGTK ships no WebRTC backend, so calling
  //     stays unsupported there regardless (verified: RTCPeerConnection undefined
  //     with enable-webrtc on, webkit2gtk 2.52.3).
  try {
    if (!window.chrome && isChromeUA) {
      Object.defineProperty(window, "chrome", {
        configurable: true,
        enumerable: true,
        writable: true,
        value: { app: { isInstalled: false }, runtime: {} },
      });
    }
  } catch (e) {}

  // Privacy blur (privacy.js) decides what a notification may show while the
  // blur is on; without it, or on any error, the notification is unchanged.
  function privacyMask(title, options) {
    try {
      var p = window.__whatrustPrivacy;
      if (p && typeof p.mask === "function") return p.mask(title, options);
    } catch (e) {}
    return { title: title, options: options };
  }

  // 2) Notification override — forward to a native OS notification via Rust.
  try {
    var OriginalNotification = window.Notification;
    // Request the actual browser permission as well as advertising our own
    // bridge permission. A shim-only grant cannot enable worker notifications.
    if (window.__WHATRUST_WINDOWS__ && OriginalNotification && OriginalNotification.requestPermission) {
      Promise.resolve().then(function(){return OriginalNotification.permission === "granted" ? "granted" : OriginalNotification.requestPermission();}).then(function(permission){
        notePath("browser permission " + (permission === "granted" ? "granted" : "not granted; page fallback"));
      }).catch(function(){notePath("browser permission unavailable; page fallback");});
    }
    function ShimNotification(title, options) {
      var masked = privacyMask(title, options);
      title = masked.title; options = masked.options;
      if (window.__whatrustPreferNative && typeof OriginalNotification === "function" && OriginalNotification.permission === "granted") {
        try {
          notePath("native Notification()");
          var notification = new OriginalNotification(title, options);
          nativeIcon(title, options);
          if(notification.addEventListener)notification.addEventListener("error",function(){notePath("native notification error; page fallback");options=options||{};nativeNotify(title,options.body,options.icon);},{once:true});
          return notification;
        } catch (e) { notePath("native constructor refused; page fallback"); }
      }
      options = options || {};
      this.title = title;
      this.body = options.body || "";
      this.onclick = null;
      this.onclose = null;
      this.onerror = null;
      this.onshow = null;
      notePath("page Notification()");
      nativeNotify(title, options.body, options.icon);
    }
    ShimNotification.prototype.close = function () {
      if (typeof this.onclose === "function") this.onclose();
    };
    ShimNotification.prototype.addEventListener = function () {};
    ShimNotification.prototype.removeEventListener = function () {};
    ShimNotification.permission = "granted";
    ShimNotification.requestPermission = function (cb) {
      if (typeof cb === "function") cb("granted");
      return Promise.resolve("granted");
    };
    window.Notification = ShimNotification;
  } catch (e) {}

  // 2a) Permissions API. The shim above reports Notification.permission
  //     "granted", but navigator.permissions.query({name:"notifications"}) still
  //     asks the engine, which answers "prompt" (WebView2 has no notification
  //     grant from us, WebKit none either). A page that checks permission that way
  //     sees notifications as off and never raises one — while still playing its
  //     own in-page sound, which is exactly the Windows report in issue #3. Answer
  //     "granted" for notifications so both APIs agree; other permissions pass
  //     through to the engine untouched.
  try {
    var perms = navigator.permissions;
    if (perms && typeof perms.query === "function") {
      var nativeQuery = perms.query.bind(perms);
      perms.query = function (desc) {
        if (desc && desc.name === "notifications") {
          return Promise.resolve({
            name: "notifications",
            state: "granted",
            status: "granted",
            onchange: null,
            addEventListener: function () {},
            removeEventListener: function () {},
            dispatchEvent: function () { return false; },
          });
        }
        return nativeQuery(desc);
      };
    }
  } catch (e) {}

  // 2b) Service-worker notification path. Modern WhatsApp Web also raises notifications
  //     via ServiceWorkerRegistration.showNotification (e.g. when the tab is backgrounded),
  //     which the window.Notification shim above does NOT intercept — so those toasts never
  //     reached the OS. Override the page-side prototype method to forward through the same
  //     native `notify` command, and report an empty list from getNotifications (we render a
  //     native toast, so there is no in-page Notification object to hand back). We can only
  //     reach the page's prototype here; notifications fired from inside the service worker's
  //     own context are out of scope for a page-injected script.
  try {
    var SWR = window.ServiceWorkerRegistration;
    if (SWR && SWR.prototype && typeof SWR.prototype.showNotification === "function") {
      // WebView2's NotificationReceived contract covers non-persistent
      // Notification() events. A persistent showNotification() promise can
      // resolve without that event, so the page-side registration uses our
      // own service directly, even when the constructor uses native delivery.
      SWR.prototype.showNotification = function (title, options) {
        var masked = privacyMask(title, options);
        title = masked.title; options = masked.options || {};
        notePath("page registration.showNotification()");
        // Route through nativeNotify so the service-worker path shares the same de-dup
        // window as window.Notification (an alert that fires on both paths shows once).
        nativeNotify(title, options.body, options.icon);
        // Real API resolves Promise<undefined>; match it so callers awaiting it don't break.
        return Promise.resolve();
      };
      if (typeof SWR.prototype.getNotifications === "function") {
        SWR.prototype.getNotifications = function () {
          return Promise.resolve([]);
        };
      }
    }
  } catch (e) {}

  // 2c) Service-worker registration, for the diagnostic log: a notification the
  //     service worker raises itself never passes through the shims above, so
  //     knowing a worker is installed explains a silent message (issue #3). The
  //     path of WhatsApp's own script only; nothing about the user.
  try {
    var swc = navigator.serviceWorker;
    if (swc && typeof swc.register === "function") {
      var nativeRegister = swc.register.bind(swc);
      swc.register = function (url, opts) {
        try {
          var path = new URL(String(url), window.location.href || window.location.origin).pathname;
          notePath("service worker registered (" + path.slice(0, 80) + ")");
        } catch (e) {}
        return nativeRegister(url, opts);
      };
    }
  } catch (e) {}

  // 2d) WhatsApp's own alert tones. The page plays message sounds through
  //     `new Audio(...)` elements it creates once and reuses for the whole
  //     session (WAWebNotificationTone and friends). Those are independent of
  //     whatRust's notifications, so turning notifications off does not silence
  //     them. Track the elements that constructor creates and mute only the
  //     bundled UI tones while the user has notification sounds off.
  //
  //     Chat audio (voice notes, audio messages, status) also goes through
  //     `new Audio`, but with a `blob:` URL: WhatsApp decrypts the media in the
  //     page and hands it to the element that way. Only the alert tones come
  //     from static.whatsapp.net. A looped element — the incoming-call ringtone
  //     — is left alone.
  (function () {
    var soundOn = window.__whatrustSound !== false;
    // Every element the Audio constructor made, held weakly: voice notes go
    // through `new Audio` too, and a plain list would keep each one (and its
    // decoded media) alive for the whole session.
    var constructed = typeof WeakSet === "function" ? new WeakSet() : null;
    // Only the alert tones seen so far (a handful), so the toggle can reach them.
    var alertAudios = [];
    var silencedByUs = [];
    function isAlertAudio(el) {
      if (!constructed || !constructed.has(el) || el.loop || el.isConnected) return false;
      var src = String(el.currentSrc || el.src || "");
      return /^https:\/\/static\.whatsapp\.net\//i.test(src);
    }
    function remember(el) {
      if (isAlertAudio(el) && alertAudios.indexOf(el) < 0) alertAudios.push(el);
    }
    function silence(el) {
      if (soundOn || !isAlertAudio(el) || el.muted) return;
      el.muted = true;
      if (silencedByUs.indexOf(el) < 0) silencedByUs.push(el);
    }
    try {
      if (typeof window.Audio === "function" && window.HTMLMediaElement) {
        var NativeAudio = window.Audio;
        var nativePlay = window.HTMLMediaElement.prototype.play;
        window.Audio = new Proxy(NativeAudio, {
          construct: function (target, args) {
            var el = Reflect.construct(target, args);
            if (constructed) constructed.add(el);
            remember(el);
            return el;
          },
        });
        window.HTMLMediaElement.prototype.play = function () {
          remember(this);
          silence(this);
          return nativePlay.apply(this, arguments);
        };
      }
    } catch (e) {}
    function apply(on) {
      soundOn = on !== false;
      for (var i = 0; i < alertAudios.length; i++) {
        var el = alertAudios[i];
        if (el.loop) continue;
        if (soundOn) {
          if (silencedByUs.indexOf(el) >= 0) el.muted = false;
        } else {
          silence(el);
        }
      }
      if (soundOn) silencedByUs = [];
    }
    window.__whatrustSetNotificationSound = apply;
    apply(soundOn);
  })();

  // 3) Unread count — forward the raw <title> string on change; Rust parses it.
  // `settled`: the page has been up long enough that a rising count means new
  // messages, not WhatsApp syncing after a launch or reload (Rust only raises
  // its unread fallback alert once settled).
  var lastTitle = "";
  var pageStart = Date.now();
  var SETTLE_MS = 30000;
  function report() {
    if (document.title === lastTitle) return;
    lastTitle = document.title;
    invoke("set_unread", { title: document.title, settled: Date.now() - pageStart > SETTLE_MS });
  }
  function start() {
    try {
      var el = document.querySelector("title");
      if (el) {
        new MutationObserver(report).observe(el, {
          childList: true,
          characterData: true,
          subtree: true,
        });
      }
      setInterval(report, 2000); // fallback if <title> node is swapped
      report();
    } catch (e) {}
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }

  // 3b) Download toast (issue #21). Rust calls __whatrustDownloadDone when a
  //     download finishes: {ok:true,id,name,canOpen} or {ok:false}. Show a small
  //     browser-style confirmation with Open / Show in folder, or the failure.
  //     It lives in a shadow root so WhatsApp's styles can't reach it, the file
  //     name is set as text (never parsed as HTML), and the buttons only send the
  //     download's id back — Rust holds the path and decides what may be opened.
  try {
    var dl = {};
    dl.MAX = 3;
    dl.TTL = 8000;
    dl.host = null;
    dl.root = null;
    dl.mount = function () {
      if (dl.host && dl.host.isConnected) return dl.root;
      var body = document.body;
      if (!body) return null;
      dl.host = document.createElement("div");
      dl.host.setAttribute("data-whatrust", "downloads");
      dl.root = dl.host.attachShadow ? dl.host.attachShadow({ mode: "closed" }) : dl.host;
      var style = document.createElement("style");
      style.textContent = [
        ":host{all:initial}",
        ".stack{position:fixed;left:16px;bottom:16px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;max-height:calc(100vh - 32px);overflow-y:auto;scrollbar-width:thin;scrollbar-color:rgba(134,150,160,.45) transparent;",
        "font:14px/1.35 system-ui,-apple-system,'Segoe UI',Roboto,Ubuntu,sans-serif;max-width:min(380px,calc(100vw - 32px))}",
        ".stack::-webkit-scrollbar{width:8px}.stack::-webkit-scrollbar-track{background:transparent}.stack::-webkit-scrollbar-thumb{background-color:rgba(134,150,160,.45);border:2px solid transparent;border-radius:4px;background-clip:padding-box}",
        ".toast{display:flex;align-items:center;gap:12px;padding:10px 10px 10px 14px;border-radius:10px;",
        "background:#233138;color:#e9edef;box-shadow:0 4px 18px rgba(0,0,0,.35)}",
        ".text{flex:1;min-width:0}",
        ".title{font-weight:600}",
        ".name{opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
        "button{all:unset;cursor:pointer;padding:6px 8px;border-radius:6px;color:#21c063;font-weight:600;white-space:nowrap}",
        "button:hover,button:focus-visible{background:rgba(255,255,255,.08)}",
        "button.close{color:#aebac1;font-weight:400;padding:6px 9px}",
        ".failed .title{color:#f15c6d}",
      ].join("");
      var stack = document.createElement("div");
      stack.className = "stack";
      stack.setAttribute("role", "status");
      stack.setAttribute("aria-live", "polite");
      dl.root.appendChild(style);
      dl.root.appendChild(stack);
      dl.stack = stack;
      body.appendChild(dl.host);
      return dl.root;
    };
    dl.button = function (label, cls, onClick) {
      var b = document.createElement("button");
      b.type = "button";
      b.textContent = label;
      if (cls) b.className = cls;
      b.addEventListener("click", onClick);
      return b;
    };
    dl.show = function (d) {
      if (!d || !dl.mount()) return false;
      var toast = document.createElement("div");
      toast.className = d.ok ? "toast" : "toast failed";
      var text = document.createElement("div");
      text.className = "text";
      var title = document.createElement("div");
      title.className = "title";
      title.textContent = d.ok ? L("Download concluído", "Download complete") : L("Falha no download", "Download failed");
      var name = document.createElement("div");
      name.className = "name";
      name.textContent = d.ok ? String(d.name || "") : L("Não foi possível baixar o arquivo.", "The file could not be downloaded.");
      if (d.ok) name.title = String(d.name || "");
      text.appendChild(title);
      text.appendChild(name);
      toast.appendChild(text);
      var timer = null;
      var close = function () {
        if (timer) clearTimeout(timer);
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      };
      var arm = function () {
        if (timer) clearTimeout(timer);
        timer = setTimeout(close, dl.TTL);
      };
      if (d.ok && typeof d.id === "number") {
        if (d.canOpen) {
          toast.appendChild(dl.button(L("Abrir", "Open"), "", function () {
            invoke("open_download", { id: d.id });
            close();
          }));
        }
        toast.appendChild(dl.button(L("Mostrar na pasta", "Show in folder"), "", function () {
          invoke("reveal_download", { id: d.id });
          close();
        }));
      }
      var x = dl.button("\u00d7", "close", close);
      x.setAttribute("aria-label", L("Fechar aviso", "Dismiss notice"));
      toast.appendChild(x);
      // Hovering keeps it up; leaving restarts the countdown.
      toast.addEventListener("mouseenter", function () { if (timer) clearTimeout(timer); });
      toast.addEventListener("mouseleave", arm);
      dl.stack.appendChild(toast);
      while (dl.stack.children.length > dl.MAX) dl.stack.removeChild(dl.stack.firstChild);
      arm();
      return true;
    };
    window.__whatrustDownloadDone = function (d) {
      try {
        return dl.show(d);
      } catch (e) {
        return false;
      }
    };
  } catch (e) {}

  // 4) Drag-and-drop file injection.
  //    On Linux the native webview does not reliably deliver OS file drops to the page,
  //    so Rust captures the drop (window.rs
  //    `register_drop_handler`) and STREAMS the file bytes here through
  //    `__whatrustDropFeed` as begin/chunk/end/commit messages keyed by a drop id.
  //    macOS and Windows use native webview drops and do not enter this pipeline.
  //    Chunks arrive BATCHED ({op:"chunk", parts:[b64,b64,...]}) because a
  //    synchronous WebKit eval handler that decodes every chunk inline would freeze
  //    the page's main thread for the whole transfer. Base64 stanzas are queued raw
  //    (no work inside the eval handler), then decoded incrementally between incoming
  //    batches by a yielding main-thread pump. Each stanza decode is non-preemptible,
  //    but the pump yields between stanzas so WhatsApp keeps handling events and the
  //    page does not retain the whole drop as base64 until commit.
  //    Batched transport also means ~4x fewer eval round-trips than one eval per chunk.
  //
  //    WhatsApp Web keeps a sticker-creator <input type=file> (image-only accept) ALWAYS
  //    mounted, but mounts the real "Photos & videos" input (accept includes video) and
  //    the "Document" input (accept "*") only when the attach (+) menu is opened. Targeting
  //    a file input blindly therefore lands on the sticker input — which turns photos into
  //    stickers and rejects video/documents. So we ROUTE BY TYPE: open the attach menu to
  //    mount the right input, then set its .files and fire change (React's onChange fires
  //    for synthetic bubbling events; it doesn't check isTrusted, and input.files is
  //    settable in WebKit). Images + native videos -> media input; everything else (zip,
  //    pdf, docs, webm/mkv/avi) -> document input. We never use the sticker input.
  //
  //    A MIXED drop (media + documents) routes EVERYTHING through the Document input:
  //    one composer per drop, and the document input accepts every file — a photo sent
  //    as a file still arrives, whereas the old "media wins" policy silently discarded
  //    the documents. Drops are queued and injected ONE AT A TIME (a later drop waits
  //    for the earlier composer), so two quick drops can't overwrite each other's
  //    input.files. There is no content dedupe: distinct same-named files both attach;
  //    replays are impossible because every drop carries a unique Rust-side id.
  try {
    var drop = {};
    drop.log = function (m) {
      try { console.log("[whatRust drop] " + m); } catch (e) {}
      try { invoke("dlog", { msg: String(m).slice(0, 280) }); } catch (e) {}
    };
    drop.attachFailed = function () {
      nativeNotify("whatRust", L("Não foi possível anexar os arquivos. Use o botão de anexo (+) e tente novamente.", "Could not attach the files. Use the attach button (+) and try again."));
    };
    // Decode one base64 stanza to bytes. Modern WebKit (18.4+) has
    // Uint8Array.fromBase64 — ~10x faster than atob + a char loop on multi-MB
    // stanzas, and allocates the Uint8Array natively in one pass. Fall back to atob
    // on older engines (Windows/macOS webviews are current; Linux WebKitGTK ≥ 2.46
    // is WebKit 18.x, so fromBase64 is present in practice).
    drop.b64ToBytes = function (b64) {
      if (typeof Uint8Array.fromBase64 === "function") {
        return Uint8Array.fromBase64(b64);
      }
      var bin = atob(b64), n = bin.length, u = new Uint8Array(n);
      for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i);
      return u;
    };
    // Compute a stanza's decoded length without decoding it. This keeps commit's
    // acknowledgement synchronous and cheap while still detecting a missing chunk.
    drop.b64DecodedSize = function (b64) {
      var n = String(b64 || "").length;
      if (!n) return 0;
      var pad = b64.slice(-2) === "==" ? 2 : (b64.slice(-1) === "=" ? 1 : 0);
      return Math.floor(n / 4) * 3 - pad;
    };
    // Pump queued base64 stanzas -> Uint8Array parts, a few at a time, yielding to
    // the main thread between stanzas so the page (and WhatsApp's own JS) keeps
    // handling events while a big drop streams in. Returns a promise; the queue is
    // empty when it resolves and f.got matches the bytes decoded.
    drop.pump = function (f) {
      return new Promise(function (resolve, reject) {
        (function step() {
          try {
            if (f.aborted) {
              f.b64s.length = 0;
              resolve();
              return;
            }
            var b64s = f.b64s;
            var budget = 12; // ~one animation frame before yielding
            var t0 = Date.now();
            while (b64s.length && Date.now() - t0 < budget) {
              var u = drop.b64ToBytes(b64s.shift());
              f.parts.push(u);
              f.got += u.length;
            }
            if (b64s.length) setTimeout(step, 0);
            else resolve();
          } catch (e) {
            reject(e);
          }
        })();
      });
    };
    // Start a deferred pump as soon as chunks arrive. The handler itself still returns
    // immediately, but base64 strings are released throughout the native stream instead
    // of all being retained until commit. Errors are stored for commit/drain to surface;
    // the background promise always settles cleanly (no unhandled rejection).
    drop.startPump = function (f) {
      if (f.error || f.aborted || f.pumpPromise || !f.b64s.length) {
        return f.pumpPromise || Promise.resolve();
      }
      f.pumpPromise = new Promise(function (resolve) {
        setTimeout(resolve, 0);
      }).then(function () {
        return drop.pump(f);
      }).catch(function (e) {
        f.error = e;
        f.b64s.length = 0;
        f.parts.length = 0;
        f.got = 0;
      }).then(function () {
        f.pumpPromise = null;
        if (!f.error && !f.aborted && f.b64s.length) return drop.startPump(f);
      });
      return f.pumpPromise;
    };
    // Wait for any in-flight incremental pump and drain a final tail that arrived just
    // before commit. Reject only here so the queued drop job can notify the user once.
    drop.drain = function (f) {
      if (f.error) return Promise.reject(f.error);
      return drop.startPump(f).then(function () {
        if (f.error) throw f.error;
        if (f.pumpPromise || f.b64s.length) return drop.drain(f);
      });
    };
    drop.dataTransfer = function (files) {
      var dt = new DataTransfer();
      for (var i = 0; i < files.length; i++) dt.items.add(files[i]);
      return dt;
    };
    // Only these video types are accepted by WhatsApp's Photos & Videos input; other
    // video containers (webm/mkv/avi) are rejected there and must go as a document.
    drop.NATIVE_VIDEO = { "video/mp4": 1, "video/3gpp": 1, "video/quicktime": 1 };
    drop.isMedia = function (type) {
      return /^image\//.test(type || "") || drop.NATIVE_VIDEO[type] === 1;
    };
    drop.qs = function (sels) {
      for (var i = 0; i < sels.length; i++) {
        var e = document.querySelector(sels[i]);
        if (e) return e;
      }
      return null;
    };
    // The media input is the only file input whose accept lists a video type; the sticker
    // input is image-only, so it can never match this. isConnected guards against a
    // stale input left over from a torn-down composer.
    drop.findMediaInput = function () {
      var ins = document.querySelectorAll('input[type="file"]');
      for (var i = 0; i < ins.length; i++) {
        if (ins[i].isConnected !== false && /video/i.test(ins[i].accept || "")) return ins[i];
      }
      return null;
    };
    // The document input accepts everything (accept "*"/""/no image+video). The sticker
    // input (image-only) and media input (has video) are both excluded.
    drop.findDocInput = function () {
      var ins = document.querySelectorAll('input[type="file"]');
      for (var i = 0; i < ins.length; i++) {
        if (ins[i].isConnected === false) continue;
        var a = (ins[i].accept || "").trim();
        if (a === "" || a === "*" || a === "*/*") return ins[i];
        if (!/image/i.test(a) && !/video/i.test(a)) return ins[i];
      }
      return null;
    };
    drop.openMenu = function () {
      var b = drop.qs([
        '[data-icon="plus"]',
        '[data-icon="attach-menu-plus"]',
        '[data-icon="clip"]',
        '[data-testid="clip"]',
        'button[title="Attach"]',
        '[aria-label="Attach"]',
        '[title="Attach"]',
      ]);
      if (!b) return false;
      (b.closest('button,[role="button"],div[role="button"]') || b).click();
      return true;
    };
    // The attach menu's "Photos & videos" / "Document" entry, most specific selector first.
    drop.menuItemSelectors = function (kind) {
      return kind === "media"
        ? ['[data-testid="attach-image"]', '[data-icon="media-multiple"]', '[aria-label*="Photos"]', '[aria-label*="hoto"]']
        : ['[data-testid="attach-document"]', '[data-icon="document"]', '[aria-label*="Document"]', '[aria-label*="ocument"]'];
    };
    // Every element on the page that matches a menu-item selector.
    drop.menuItemMatches = function (kind) {
      var sels = drop.menuItemSelectors(kind), out = [];
      for (var i = 0; i < sels.length; i++) {
        var found = document.querySelectorAll(sels[i]);
        for (var j = 0; j < found.length; j++) out.push(found[j]);
      }
      return out;
    };
    // The first menu-item match that is not in `stale`. The loose aria-label selectors
    // can also match things outside the menu (a "Profile photo" button, say); anything
    // already on the page before the menu opened is one of those, never the menu item.
    drop.findMenuItem = function (kind, stale) {
      var all = drop.menuItemMatches(kind);
      for (var i = 0; i < all.length; i++) {
        if (stale.indexOf(all[i]) === -1) return all[i];
      }
      return null;
    };
    drop.clickElement = function (e) {
      (e.closest('li,button,[role="button"],div[role="button"]') || e).click();
    };
    drop.clickMenuItem = function (kind) {
      var e = drop.qs(drop.menuItemSelectors(kind));
      if (!e) return false;
      drop.clickElement(e);
      return true;
    };
    drop.poll = function (fn, ms) {
      return new Promise(function (resolve) {
        var t0 = Date.now();
        (function p() {
          var r = fn();
          if (r) return resolve(r);
          if (Date.now() - t0 >= ms) return resolve(null);
          setTimeout(p, 60);
        })();
      });
    };
    drop.inject = function (input, files) {
      var dt = drop.dataTransfer(files);
      try {
        input.files = dt.files; // settable in WebKit + Blink (WHATWG html#2861)
      } catch (e) {
        drop.log("input.files assign threw: " + e);
        return false;
      }
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    };
    // Open the attach menu and inject into the file input matching `kind`. Current
    // WhatsApp Web mounts that input only when the menu's "Photos & videos" or
    // "Document" entry is clicked, not when the menu opens. So after opening the menu,
    // watch for EITHER the input (older versions mount it with the menu) OR the menu
    // entry, and click the entry the moment it renders. Waiting for the input alone
    // used to sit out its full 1 s timeout before clicking the entry (a visible delay
    // on every drop and paste). No user gesture exists here, so the OS file picker
    // can't open; only the input element is mounted, which is all we need.
    drop.mountAndInject = function (kind, files) {
      var find = kind === "media" ? drop.findMediaInput : drop.findDocInput;
      var started = Date.now();
      var injectInto = function (input, how) {
        drop.log(kind + " input " + how + " after " + (Date.now() - started) + "ms");
        return drop.inject(input, files);
      };
      var existing = find();
      if (existing) return Promise.resolve(injectInto(existing, "already present"));

      var stale = drop.menuItemMatches(kind);
      drop.openMenu();
      return drop.poll(function () {
        var input = find();
        if (input) return { input: input };
        var item = drop.findMenuItem(kind, stale);
        return item ? { item: item } : null;
      }, 1000).then(function (hit) {
        if (hit && hit.input) return injectInto(hit.input, "mounted with the menu");
        // The entry rendered: click it. Nothing rendered within 1 s: the menu may be a
        // version whose entry was already on the page, so try the plain lookup once.
        if (hit) drop.clickElement(hit.item);
        else drop.clickMenuItem(kind);
        return drop.poll(find, 1000).then(function (input) {
          if (input) return injectInto(input, "mounted by the menu entry");
          drop.log(kind + " input NOT found after opening attach menu");
          return false;
        });
      });
    };
    // WhatsApp opens a media/document preview composer once a file is attached; used both
    // as the success signal and to hold the NEXT queued drop until the current composer
    // is closed. Best-effort selectors across WA Web versions.
    drop.composerOpen = function () {
      return !!(
        document.querySelector('[data-testid="media-caption-input-container"]') ||
        document.querySelector('[data-testid="media-editor"]') ||
        document.querySelector('[data-animate-modal-body="true"]') ||
        document.querySelector('span[data-icon="send"]') ||
        document.querySelector('span[data-icon="media-cancel"]')
      );
    };
    drop.waitFor = function (pred, ms) {
      return new Promise(function (resolve) {
        var t0 = Date.now();
        (function poll() {
          if (pred()) return resolve(true);
          if (Date.now() - t0 >= ms) return resolve(false);
          setTimeout(poll, 80);
        })();
      });
    };

    // --- chunked receive state ---
    // pending[dropId] = { files: { idx: {name,type,size,parts:[Uint8Array],got} } }
    drop.pending = Object.create(null);
    // Discard a stream that never commits (e.g. Rust died mid-drop) after 60s.
    drop.touch = function (st) {
      if (st.gc) clearTimeout(st.gc);
      st.gc = setTimeout(function () {
        delete drop.pending[st.id];
        drop.log("drop #" + st.id + " expired uncommitted");
      }, 60000);
    };
    drop.state = function (id) {
      var st = drop.pending[id];
      if (!st) {
        st = drop.pending[id] = { id: id, files: Object.create(null) };
      }
      drop.touch(st);
      return st;
    };

    // Serialized injection queue: one drop's composer at a time. Rust's per-window
    // FIFO stream worker guarantees commits reach this queue in original OS event order.
    drop.queue = Promise.resolve();
    drop.runQueued = function (job) {
      drop.queue = drop.queue.then(job, job);
    };

    drop.injectBatch = function (files) {
      var media = files.filter(function (f) { return drop.isMedia(f.type); });
      var docs = files.filter(function (f) { return !drop.isMedia(f.type); });
      // One composer per drop. A mixed batch goes WHOLLY through the document
      // input (it accepts everything) so no file is ever silently discarded.
      var kind, batch;
      if (media.length && docs.length) {
        kind = "document";
        batch = files;
        drop.log("mixed drop: routing all " + files.length + " file(s) as documents");
      } else if (media.length) {
        kind = "media";
        batch = media;
      } else {
        kind = "document";
        batch = docs;
      }
      drop.log("drop: injecting " + batch.length + " file(s) via " + kind + " input");
      return drop.mountAndInject(kind, batch).then(function (ok) {
        drop.log(kind + " inject " + (ok ? "dispatched" : "FAILED"));
        return drop.waitFor(drop.composerOpen, 1800).then(function (open) {
          drop.log("composer " + (open ? "opened" : "NOT detected") + " (" + kind + ")");
          if (!open) return;
          // Hold the queue until this composer closes (sent/cancelled), so the
          // next drop doesn't fight it for the attach flow. Bounded wait.
          return drop.waitFor(function () { return !drop.composerOpen(); }, 120000);
        });
      });
    };

    // Rust-side feed. Messages: {op:"begin",drop,file,name,type,size} ->
    // {op:"chunk",drop,file,b64}* -> {op:"end",drop,file} | {op:"abort",drop,file},
    // then one {op:"commit",drop,files}. Returns a string ack for commit (read by
    // eval_with_callback in Rust, proving the handler executed).
    window.__whatrustDropFeed = function (msg) {
      try {
        if (!msg || typeof msg.drop !== "number") return "BADMSG";
        var st = drop.state(msg.drop);
        if (msg.op === "begin") {
          st.files[msg.file] = {
            name: String(msg.name || "file"),
            type: String(msg.type || "application/octet-stream"),
            size: msg.size >>> 0,
            b64s: [], // raw base64 stanzas waiting to be pumped
            parts: [], // decoded Uint8Array chunks
            got: 0,
            done: false,
            aborted: false,
            error: null,
            pumpPromise: null,
          };
          return "OK";
        }
        var f = st.files[msg.file];
        if (msg.op === "chunk") {
          if (!f || f.done) return "NOFILE";
          // Queue raw stanzas and schedule decode after this synchronous eval handler
          // returns. Decoding then proceeds incrementally while Rust streams later batches.
          var ps = msg.parts || (msg.b64 ? [msg.b64] : []);
          for (var i = 0; i < ps.length; i++) f.b64s.push(ps[i]);
          drop.startPump(f);
          return "OK";
        }
        if (msg.op === "end") {
          if (f) f.done = true;
          return "OK";
        }
        if (msg.op === "abort") {
          if (f) {
            f.aborted = true;
            f.b64s.length = 0;
            f.parts.length = 0;
          }
          delete st.files[msg.file];
          drop.log("drop #" + st.id + " file " + msg.file + " aborted by sender");
          return "OK";
        }
        if (msg.op === "commit") {
          if (st.gc) clearTimeout(st.gc);
          delete drop.pending[st.id];
          var entries = Object.keys(st.files).map(function (k) { return st.files[k]; });
          var hadDecodeError = false;
          // Decoded bytes plus still-queued stanza lengths reveal the exact received size
          // without waiting for the incremental pump to finish.
          var valid = entries.filter(function (e) {
            if (e.error) {
              hadDecodeError = true;
              drop.log("drop #" + st.id + " decode failed before commit: " + e.error);
              return false;
            }
            var received = e.got + e.b64s.reduce(function (n, b64) {
              return n + drop.b64DecodedSize(b64);
            }, 0);
            if (!e.done || received !== e.size) {
              drop.log("drop #" + st.id + " file incomplete (" + received + "/" + e.size + "), skipped");
              return false;
            }
            return true;
          });
          if (valid.length === 0) return hadDecodeError ? "ERR" : "EMPTY";
          // A pure error returns ERR for Rust to notify. When healthy files remain,
          // commit must still return QUEUED:n, so notify the partial failure here.
          if (hadDecodeError) drop.attachFailed();
          // Reserve the already-arrival-ordered commit in the composer queue. The native
          // FIFO worker prevents a later small drop from committing first; this queue
          // separately prevents two attachment composers from fighting each other.
          drop.runQueued(function () {
            var files = [];
            return valid.reduce(function (p, e) {
              return p.then(function () {
                return drop.drain(e).then(function () {
                  if (e.got !== e.size) {
                    drop.log("drop #" + st.id + " decode size mismatch (" + e.got + "/" + e.size + "), skipped");
                    return;
                  }
                  files.push(new File(e.parts, e.name, { type: e.type }));
                  e.parts = null; // release chunk refs once the File owns the data
                  e.b64s = null;
                });
              });
            }, Promise.resolve()).then(function () {
              if (files.length === 0) {
                drop.log("drop #" + st.id + " had no complete files");
                return;
              }
              return drop.injectBatch(files).catch(function (e) {
                drop.log("inject error: " + e);
                drop.attachFailed();
              });
            }).catch(function (e) {
              drop.log("decode error: " + e);
              drop.attachFailed();
            });
          });
          return "QUEUED:" + valid.length;
        }
        return "BADOP";
      } catch (e) {
        drop.log("feed error: " + e);
        return "ERR";
      }
    };
    drop.log("drop injector v5 (batched chunks, incremental decode, ordered no-loss routing) ready");

    // 5) Clipboard paste of images and files (Linux).
    //    WebKitGTK hides both from the page and refuses navigator.clipboard.read():
    //      - an image (screenshot, "Copy image") arrives as an EMPTY clipboardData;
    //      - files copied in a file manager (PDF, video, ...) arrive as type
    //        text/uri-list whose getData() is "" and with no files.
    //    Either way WhatsApp gets nothing to attach. When a paste carries no file
    //    and no plain text, ask Rust to read the system clipboard (clipboard.rs).
    //    Copied files are streamed back through __whatrustDropFeed above, like a
    //    drop; an image comes back as base64 PNG and goes through the same queue
    //    and composer routing as a dropped photo.
    //    Windows and macOS put pasted images and files in clipboardData.files, and
    //    a text paste has text/plain, so neither ever reaches Rust.
    drop.pasteNeedsNativeRead = function (data) {
      if (!data) return false;
      if (data.files && data.files.length) return false; // the webview delivered it
      var types = Array.prototype.slice.call(data.types || []);
      return types.indexOf("text/plain") === -1;
    };
    drop.pasteFromClipboard = function () {
      return invoke("paste_clipboard").then(function (b64) {
        // "" means no image: either nothing usable was on the clipboard, or Rust
        // is streaming copied files through the drop feed. undefined means the
        // command was refused (locked, background account).
        if (typeof b64 !== "string" || !b64) return;
        // "image.png" is the name Chrome gives a pasted image.
        var file = new File([drop.b64ToBytes(b64)], "image.png", { type: "image/png" });
        drop.log("paste: attaching clipboard image (" + file.size + " bytes)");
        drop.runQueued(function () {
          return drop.injectBatch([file]).catch(function (e) {
            drop.log("paste inject error: " + e);
            drop.attachFailed();
          });
        });
      });
    };
    // Capture phase on window: runs before WhatsApp's own handlers, so a
    // stopPropagation there cannot hide the paste from us. We only read the
    // event and never cancel it, so text pastes behave exactly as before.
    window.addEventListener("paste", function (e) {
      if (drop.pasteNeedsNativeRead(e && e.clipboardData)) drop.pasteFromClipboard();
    }, true);
  } catch (e) {}
})();
